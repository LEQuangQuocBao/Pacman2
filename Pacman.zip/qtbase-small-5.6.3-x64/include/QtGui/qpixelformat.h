#include "../../src/gui/kernel/qpixelformat.h"
