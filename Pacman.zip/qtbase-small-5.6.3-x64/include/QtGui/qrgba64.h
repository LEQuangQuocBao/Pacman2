#include "../../src/gui/painting/qrgba64.h"
