#include "../../src/gui/kernel/qtouchdevice.h"
