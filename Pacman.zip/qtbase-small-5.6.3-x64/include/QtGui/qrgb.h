#include "../../src/gui/painting/qrgb.h"
