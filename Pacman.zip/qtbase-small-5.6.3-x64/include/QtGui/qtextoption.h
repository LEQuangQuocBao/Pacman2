#include "../../src/gui/text/qtextoption.h"
