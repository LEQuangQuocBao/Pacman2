#include "../../src/gui/painting/qpen.h"
