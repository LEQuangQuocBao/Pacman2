#include "../../src/gui/kernel/qgenericplugin.h"
