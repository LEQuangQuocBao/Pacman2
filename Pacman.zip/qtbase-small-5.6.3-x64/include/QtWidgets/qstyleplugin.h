#include "../../src/widgets/styles/qstyleplugin.h"
