#include "../../src/widgets/util/qsystemtrayicon.h"
