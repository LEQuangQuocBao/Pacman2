#include "../../src/widgets/itemviews/qdatawidgetmapper.h"
