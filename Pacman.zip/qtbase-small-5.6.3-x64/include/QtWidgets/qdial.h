#include "../../src/widgets/widgets/qdial.h"
