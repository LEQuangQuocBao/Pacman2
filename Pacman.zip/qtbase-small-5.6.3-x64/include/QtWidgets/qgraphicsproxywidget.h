#include "../../src/widgets/graphicsview/qgraphicsproxywidget.h"
