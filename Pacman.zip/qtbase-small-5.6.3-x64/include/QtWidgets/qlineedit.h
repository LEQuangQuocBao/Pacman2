#include "../../src/widgets/widgets/qlineedit.h"
