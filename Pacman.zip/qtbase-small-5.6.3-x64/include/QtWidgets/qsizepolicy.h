#include "../../src/widgets/kernel/qsizepolicy.h"
