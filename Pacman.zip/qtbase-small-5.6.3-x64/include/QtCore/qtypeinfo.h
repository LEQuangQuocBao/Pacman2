#include "../../src/corelib/global/qtypeinfo.h"
