#include "../../src/corelib/plugin/qpluginloader.h"
