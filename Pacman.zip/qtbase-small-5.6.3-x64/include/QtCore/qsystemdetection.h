#include "../../src/corelib/global/qsystemdetection.h"
