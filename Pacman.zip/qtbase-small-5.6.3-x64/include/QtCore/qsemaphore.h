#include "../../src/corelib/thread/qsemaphore.h"
