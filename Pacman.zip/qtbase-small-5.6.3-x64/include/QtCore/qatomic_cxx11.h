#include "../../src/corelib/arch/qatomic_cxx11.h"
