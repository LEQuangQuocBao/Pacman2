#include "../../src/corelib/global/qflags.h"
