#include "../../src/corelib/global/qtypetraits.h"
