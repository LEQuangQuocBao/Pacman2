#include "../../src/corelib/thread/qfuture.h"
