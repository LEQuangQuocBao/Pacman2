#include "../../src/corelib/io/qtemporarydir.h"
