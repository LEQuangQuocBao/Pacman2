#include "../../src/corelib/tools/qsize.h"
