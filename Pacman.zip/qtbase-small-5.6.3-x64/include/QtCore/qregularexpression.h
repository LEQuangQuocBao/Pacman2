#include "../../src/corelib/tools/qregularexpression.h"
