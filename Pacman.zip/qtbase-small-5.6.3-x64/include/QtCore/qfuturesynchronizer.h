#include "../../src/corelib/thread/qfuturesynchronizer.h"
