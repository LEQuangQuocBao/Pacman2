#include "../../src/corelib/global/qisenum.h"
