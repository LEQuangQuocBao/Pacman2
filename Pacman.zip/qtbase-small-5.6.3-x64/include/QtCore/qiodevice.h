#include "../../src/corelib/io/qiodevice.h"
