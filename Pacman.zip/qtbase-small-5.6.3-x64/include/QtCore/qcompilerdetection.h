#include "../../src/corelib/global/qcompilerdetection.h"
