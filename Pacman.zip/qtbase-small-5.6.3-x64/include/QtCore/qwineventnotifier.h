#include "../../src/corelib/kernel/qwineventnotifier.h"
