#include "../../src/corelib/arch/qatomic_armv6.h"
