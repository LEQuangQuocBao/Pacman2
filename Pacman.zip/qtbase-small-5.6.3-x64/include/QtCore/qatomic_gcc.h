#include "../../src/corelib/arch/qatomic_gcc.h"
