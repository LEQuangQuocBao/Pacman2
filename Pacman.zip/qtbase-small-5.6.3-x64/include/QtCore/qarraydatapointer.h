#include "../../src/corelib/tools/qarraydatapointer.h"
