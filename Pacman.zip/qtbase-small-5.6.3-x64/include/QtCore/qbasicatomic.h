#include "../../src/corelib/thread/qbasicatomic.h"
