#include "../../src/corelib/global/qsysinfo.h"
