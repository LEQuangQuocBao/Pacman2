#include "../../src/gui/kernel/qclipboard.h"
