#include "../../src/gui/text/qstatictext.h"
