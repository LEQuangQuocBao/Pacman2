#include "../../src/gui/painting/qcolor.h"
