#include "../../src/gui/kernel/qsessionmanager.h"
