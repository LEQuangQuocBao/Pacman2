#include "../../src/gui/painting/qpaintdevice.h"
