#include "../../src/gui/painting/qpolygon.h"
