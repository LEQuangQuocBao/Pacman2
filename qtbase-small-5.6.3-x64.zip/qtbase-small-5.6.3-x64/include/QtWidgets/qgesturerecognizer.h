#include "../../src/widgets/kernel/qgesturerecognizer.h"
