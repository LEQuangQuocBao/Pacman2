#include "../../src/widgets/kernel/qshortcut.h"
