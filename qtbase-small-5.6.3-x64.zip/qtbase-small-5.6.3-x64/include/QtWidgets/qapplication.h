#include "../../src/widgets/kernel/qapplication.h"
