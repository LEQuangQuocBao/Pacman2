#include "../../src/widgets/statemachine/qmouseeventtransition.h"
