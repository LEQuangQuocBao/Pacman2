#include "../../src/widgets/widgets/qsizegrip.h"
