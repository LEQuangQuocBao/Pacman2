#include "../../src/widgets/widgets/qmdiarea.h"
