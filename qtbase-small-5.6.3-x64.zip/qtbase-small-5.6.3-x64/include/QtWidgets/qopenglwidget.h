#include "../../src/widgets/kernel/qopenglwidget.h"
