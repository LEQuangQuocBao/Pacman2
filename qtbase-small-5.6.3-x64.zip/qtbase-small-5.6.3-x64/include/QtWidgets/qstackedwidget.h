#include "../../src/widgets/widgets/qstackedwidget.h"
