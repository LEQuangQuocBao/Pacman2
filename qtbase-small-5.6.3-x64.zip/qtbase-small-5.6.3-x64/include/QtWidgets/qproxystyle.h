#include "../../src/widgets/styles/qproxystyle.h"
