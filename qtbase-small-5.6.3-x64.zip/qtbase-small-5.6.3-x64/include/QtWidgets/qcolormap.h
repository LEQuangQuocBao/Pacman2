#include "../../src/widgets/util/qcolormap.h"
