#include "../../src/widgets/widgets/qsplashscreen.h"
