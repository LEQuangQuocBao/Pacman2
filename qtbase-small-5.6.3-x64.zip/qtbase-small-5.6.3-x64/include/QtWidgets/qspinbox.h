#include "../../src/widgets/widgets/qspinbox.h"
