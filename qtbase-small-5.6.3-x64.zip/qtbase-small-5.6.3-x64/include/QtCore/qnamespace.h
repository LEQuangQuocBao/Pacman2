#include "../../src/corelib/global/qnamespace.h"
