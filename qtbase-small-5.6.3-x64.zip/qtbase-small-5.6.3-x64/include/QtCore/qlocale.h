#include "../../src/corelib/tools/qlocale.h"
