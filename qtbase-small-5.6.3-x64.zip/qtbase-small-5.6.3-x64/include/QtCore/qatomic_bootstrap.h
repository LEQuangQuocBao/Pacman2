#include "../../src/corelib/arch/qatomic_bootstrap.h"
