#include "../../src/corelib/statemachine/qsignaltransition.h"
