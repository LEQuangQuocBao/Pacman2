#include "../../src/corelib/global/qlogging.h"
