#include "../../src/corelib/statemachine/qabstracttransition.h"
