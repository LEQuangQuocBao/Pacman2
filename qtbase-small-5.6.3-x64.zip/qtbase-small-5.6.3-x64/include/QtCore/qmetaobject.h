#include "../../src/corelib/kernel/qmetaobject.h"
