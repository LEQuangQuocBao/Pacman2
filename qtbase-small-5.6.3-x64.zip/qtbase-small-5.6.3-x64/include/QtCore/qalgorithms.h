#include "../../src/corelib/tools/qalgorithms.h"
