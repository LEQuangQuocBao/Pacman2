#include "../../src/corelib/global/qprocessordetection.h"
