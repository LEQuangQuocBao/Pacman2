#include "../../src/corelib/tools/qrect.h"
