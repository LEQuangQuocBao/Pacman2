#include "../../src/corelib/arch/qatomic_x86.h"
