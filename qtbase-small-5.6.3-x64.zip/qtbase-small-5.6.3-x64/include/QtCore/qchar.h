#include "../../src/corelib/tools/qchar.h"
