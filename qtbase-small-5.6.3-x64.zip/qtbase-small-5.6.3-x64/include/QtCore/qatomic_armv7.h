#include "../../src/corelib/arch/qatomic_armv7.h"
