#include "../../src/corelib/io/qsettings.h"
