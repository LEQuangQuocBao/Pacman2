#include "../../src/corelib/tools/qcollator.h"
