#include "../../src/corelib/kernel/qobjectdefs_impl.h"
