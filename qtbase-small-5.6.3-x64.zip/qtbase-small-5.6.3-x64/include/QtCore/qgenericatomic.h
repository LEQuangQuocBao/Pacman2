#include "../../src/corelib/thread/qgenericatomic.h"
