#include "../../src/corelib/arch/qatomic_unix.h"
